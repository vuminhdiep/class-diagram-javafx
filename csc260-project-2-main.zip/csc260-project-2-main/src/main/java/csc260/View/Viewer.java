package csc260.View;

import csc260.Document.WhiteCanvasModel;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public interface Viewer {
    public void update();

}
