package csc260.Document;

public class MappingEdges {
    public static final int INHERITANCE = 0; //empty big white triangle
    public static final int DELEGATION = 1; // empty big white diamond
    public static final int CONTAINMENT = 2; // small black triangle
}